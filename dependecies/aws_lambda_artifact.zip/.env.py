DB_HOST= "busappdb.c9wo86eco8pm.eu-north-1.rds.amazonaws.com"
DB_USER= "admin"
DB_PASSWORD="Graphic8012"
DB_NAME= "busappdb"